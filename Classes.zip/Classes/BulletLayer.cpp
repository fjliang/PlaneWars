#include "BulletLayer.h"
#include "PlaneLayer.h"


BulletLayer::BulletLayer()
{
	m_pAllBullet = Array::create();
	m_pAllBullet->retain();
}

BulletLayer::~BulletLayer()
{
	m_pAllBullet->release();
	m_pAllBullet = NULL;
}
SpriteBatchNode* bulletBatchNode;
bool BulletLayer::init(){
	bool bRet = false;
	do{
		CC_BREAK_IF(!Layer::init());
		Texture2D* texture= TextureCache::sharedTextureCache()->textureForKey("/ui/shoot.png");
		bulletBatchNode=SpriteBatchNode::createWithTexture(texture);
		this->addChild(bulletBatchNode);

		bRet = true;
	} while (0);
	return bRet;
}
void BulletLayer::addBullet(float dt){
	Sprite* bullet = Sprite::createWithSpriteFrameName("bullet1.png");
	bulletBatchNode->addChild(bullet);
	Node* pLayer= PlaneLayer::sharedPlane->getChildByTag(PlaneLayer::AIRPLANE);
	Point planePostion = pLayer->getPosition();
	Point bulletPostion = ccp(planePostion.x, planePostion.y + pLayer->getContentSize().height/2);
	bullet->setPosition(bulletPostion);

	bulletMove(bullet);
}

void BulletLayer::bulletMoveFinished(Node* pSender){
	Sprite* bullet = (Sprite*)pSender;
	m_pAllBullet->removeObject(bullet);
	bulletBatchNode->removeChild(bullet,true);
}

void BulletLayer::startShoot(float delay){

	this->schedule(schedule_selector(BulletLayer::addBullet), 0.2f, kRepeatForever, delay);

}

void BulletLayer::removeBullet(Sprite* bullet){
	if (bullet!=NULL){
		this->m_pAllBullet->removeObject(bullet);
		bulletBatchNode->removeChild(bullet,true);
	}
}

void BulletLayer::bulletMove(Sprite* bullet){
	//��Ļ�߶�
	float screenHeight=Director::sharedDirector()->getWinSize().height;
	//�ӵ����о���
	float length = screenHeight + bullet->getContentSize().height / 2 - bullet->getPosition().y;
	float velocity = 420 / 1;//�����ٶ� 420pix/sec
	float relaMoveDuration = length / velocity;
	FiniteTimeAction* actionMove= MoveTo::create(relaMoveDuration, ccp(bullet->getPosition().x, screenHeight+bullet->getContentSize().height/2));
	FiniteTimeAction* actionDone = CallFuncN::create(this, callfuncN_selector(BulletLayer::bulletMoveFinished));//�ص��ӵ������Ĵ�������
	Sequence* sequence = Sequence::create(actionMove, actionDone,NULL);
	bullet->runAction(sequence);
}

void BulletLayer::stopShoot(){
	this->unschedule(schedule_selector(BulletLayer::addBullet));
}

