#include "EnemyLayer.h"


EnemyLayer::EnemyLayer()
{
	m_pAllEnemy = Array::create();
	m_pAllEnemy->retain();
	/*Texture2D* texture2D = TextureCache::sharedTextureCache()->getTextureForKey("/ui/shoot.png");
	pSpriteBatchNode= SpriteBatchNode::createWithTexture(texture2D);
	this->addChild(pSpriteBatchNode);*/
}

EnemyLayer::~EnemyLayer()
{
	m_pAllEnemy->release();
	m_pAllEnemy = NULL;
}
void EnemyLayer::enemyBlowup(Enemy* enemy){
	Animation* animation=AnimationCache::sharedAnimationCache()->animationByName("Enemy1Blowup");
	Animate* animate=Animate::create(animation);
	CCCallFuncND* removeEnemy= CCCallFuncND::create(enemy, callfuncND_selector(EnemyLayer::removeEnemy), (void*)enemy);
	Sequence* sequence=Sequence::create(animate, removeEnemy);
	enemy->getSprite()->runAction(sequence);
}

void EnemyLayer::removeEnemy(Node* pTarget, void* data){
	Enemy* enemy = (Enemy*)data;
	if (enemy!=NULL){
		m_pAllEnemy->removeObject(enemy);
		this->removeChild(enemy,true);
	}
}

void EnemyLayer::removeAllEnemy(){
	Object* obj;
	CCARRAY_FOREACH(m_pAllEnemy, obj){
		Enemy* enemy = (Enemy*)obj;
		if (enemy->getLife()>0){
			enemyBlowup(enemy);
		}
	}
}

void EnemyLayer::enemyMoveFinished(Node* pSender){
	Enemy* enemy = (Enemy*)pSender;
	m_pAllEnemy->removeObject(enemy);
	this->removeChild(enemy, true);
}
void EnemyLayer::addEnemy(float dt){

	//�󶨵л�
	Enemy* enemy = Enemy::create();
	Sprite* enemyPlane = Sprite::createWithSpriteFrame(SpriteFrameCache::sharedSpriteFrameCache()->getSpriteFrameByName("enemy1.png"));

	/*Sprite* enemy1 = Sprite::createWithSpriteFrameName("enemy1.png");
	pSpriteBatchNode->addChild(enemy1);*/
	enemy->bindSprite(enemyPlane, EnemyLayer::maxLIFE1);
	//�漴��ʼλ��
	Size enemySize= enemy->getSprite() ->getContentSize();
	Size winSize=Director::sharedDirector()->getWinSize();
	int minX = enemySize.width / 2;
	int maxX = winSize.width - enemySize.width / 2;
	//X��Χ
	int rangeX = maxX - minX;
	int actualX = rand() % rangeX + minX;
	enemy->setPosition(ccp(actualX,winSize.height+enemySize.height/2));
	this->addChild(enemy);
	EnemyLayer::m_pAllEnemy->addObject(enemy);
	//��������ٶ�
	float minDuration, maxDuration;
	minDuration = 30/1;
	maxDuration = 5/1;
	//������Ϸ�Ѷȸ�ֵ
	int rangeDuration = maxDuration - minDuration;
	int acturalDuration = rand() % rangeDuration + minDuration;
	FiniteTimeAction* actionMove = MoveTo::create(acturalDuration, ccp(actualX, -enemy->getSprite()->getContentSize().height / 2));
	FiniteTimeAction* actionDone = CallFuncN::create(this,callfuncN_selector(EnemyLayer::enemyMoveFinished));
	Sequence* sequence = Sequence::create(actionMove, actionDone, NULL);
	enemy->runAction(sequence);
}
