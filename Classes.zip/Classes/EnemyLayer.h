#pragma once
#include"cocos2d.h"
#include"Enemy.h"
USING_NS_CC;
class EnemyLayer :public cocos2d::Layer
{
public:
	EnemyLayer();
	~EnemyLayer();
	CREATE_FUNC(EnemyLayer);
	Array* m_pAllEnemy;
	const int maxLIFE1 = 2;
	const int maxLIFE2 = 5;
	const int maxLIFE3 = 10;
	SpriteBatchNode* pSpriteBatchNode;
	void addEnemy(float dt);
	//�л���ը
	void enemyBlowup(Enemy* enemy);
	void removeEnemy(Node* pTarget,void* data);
	void removeAllEnemy();
	void enemyMoveFinished(Node* pSender);
};

